<!DOCTYPE dhtml>
<HTML xmlns="http://www.w3.org/1999/xhtml" xml:lang="pt-br" lang="pt-br"> 
<HEAD>
<meta charset="utf-8" />
<meta http-equiv="content-type" content="text/html" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>WRS - Web Report System</title>
<!--Importa JS-->



		
		
<script type="text/javascript" src="./js/jquery-1.7.2.js"></script>
<script type="text/javascript" src="./js/jquery-ui-1.8.21.custom.js"></script>
<script type="text/javascript" src="./js/jquery.layout-latest.js"></script>
<script type="text/javascript" src="./js/jquery.layout.resizePaneAccordions-1.0.js"></script>

<script type="text/javascript" src="./js/jqGrid/jquery.jqGrid.min.js"></script>
<script type="text/javascript" src="./js/jqGrid/jquery.jqChart.min.js"></script>
<script type="text/javascript" src="./js/jqGrid/i18n/grid.locale-en.js"></script>

<script type="text/javascript" src="./js/contextMenu/jquery.contextMenu.js"></script>
<script type="text/javascript" src="./js/contextMenu/jquery.ui.position.js"></script>
<script type="text/javascript" src="./js/contextMenu/jquery.contextMenu.js"></script>

<script type="text/javascript" src="./js/jquery.ui.touch-punch.min.js"></script>

<!-- Biblioteca para PRINTAR a tela-->
<script type="text/javascript" src="./js/html2canvas.min.js"></script> 

<script type="text/javascript" src="./js/canvg.js"></script> 
<script type="text/javascript" src="./js/rgbcolor.js"></script> 

<script type="text/javascript" src="./js/blockUI.js"></script>

<script type="text/javascript" src="./js/googlemaps.js"></script>
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyAvq_yJP8-zcJZNuwF47gmhIGPXQhjlTgE&sensor=true"></script>


<script type="text/javascript" src="./<?php echo JS_PATH_API;?>php_js.js?<?php echo WRS_TEMP_RAND;?>"></script>
<script type="text/javascript" src="./language_javascript.php?<?php echo WRS_TEMP_RAND;?>"></script>



<script type="text/javascript" src="./<?php echo JS_PATH_API;?>common.js?<?php echo WRS_TEMP_RAND;?>"></script>

<script type="text/javascript" src="./js/overlib.js"></script>

<link href="./api/bootstrap-3.3.0/dist/css/bootstrap-wrs.css?v=1.0 " rel="stylesheet">
<link href="./api/bootstrap-3.3.0/dist/css/bootstrap-theme.min.css?v=1.0 " rel="stylesheet">

<link rel="stylesheet" type="text/css" href="./api/style.css?<?php echo WRS_TEMP_RAND;?>" />
<link rel="stylesheet" type="text/css" href="./api/jQuery-Mac-like-Dock-Menu-Plugin-jqdock/aple.css" />
<script type="text/javascript" src="../api/jQuery-Mac-like-Dock-Menu-Plugin-jqdock/jquery.jqDock.js"></script>
<!--Importa CSS-->
<link rel="stylesheet" type="text/css" href="./css/estilo.css" />
<link rel="stylesheet" type="text/css" href="./css/estilo_jquery.css" />
<link rel="stylesheet" type="text/css" href="./css/layout-default-latest.css" />

<!-- TODO:: Colocar o gerenciamneto na tela -->
<link rel="stylesheet" type="text/css" href="./css/<?php echo WRS::INFO_SSAS_LOGIN('USER_FORMAT')?>/jquery-ui-1.8.22.custom.css?v=1.0" id="themeHost"  host="./css/{host}/jquery-ui-1.8.22.custom.css?v=1.0"  />

<link rel="stylesheet" type="text/css" href="./css/ui.jqgrid.css" />
<link rel="stylesheet" type="text/css" href="./js/contextMenu/jquery.contextMenu.css" />



		



<link rel="stylesheet" type="text/css" href="./css/wrs.css" />
<?php 

	if(wrs_get_user_browser()=='ie'){
		echo '<link rel="stylesheet" type="text/css" href="./css/wrs_ie.css?'.rand(0,999999).'" />';
	}
	
	if(wrs_get_user_browser()=='firefox'){
		echo '<link rel="stylesheet" type="text/css" href="./css/wrs_firefox.css?'.rand(0,999999).'" />';
	}
?>

</HEAD>
<BODY onResize="" onLoad="">
 	