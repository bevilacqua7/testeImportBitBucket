<div class="direito_container">
<div class="wrs_title_drag ">




<div class="nav nav-tabs ui-accordion-header  ui-accordion-header-active ui-state-active wrs_panel_esquerdo_header DRAG_DROP_LATERAIS_title">
	<span class="navbar-left title_left">Atributos</span>
	<div class="navbar-right btn-group DRAG_DROP_LATERAIS_title_btn_right" >
	
			  <button type="button" class="btn btn-default btn-xs glyphicon glyphicon-floppy-disk"></button>
					  <button type="button" class="btn btn-default btn-xs glyphicon glyphicon-folder-open"></button>
	</div>
				</div>

	
	
					
					
</div>
<div id="products" class="wrs_options_select wrs_options_panel_atributo">
  <div class="WRS_DRAG_DROP WRS_DRAG_DROP_ATTR">
    <h2><a href="#">T-Shirts</a>
    		<button type="button" class="btn btn-link btn-xs navbar-right wrs_search_drad_drop_direita"><span class="glyphicon glyphicon-search "></span></button>	 
		</h2>
		    
    <div class="wrs_panel_options">
      <ul>
        <li class="ui-widget-content box_wrs_panel" name="dantas" api="wrs"   vvalue="Lolcat Shirt"><span class="btn-left glyphicon glyphicon glyphicon-font"></span>  Lolcat Shirt</li>
        <li class="ui-widget-content box_wrs_panel" api="wrs"   vvalue="Cheezeburger Shirt"><span class="btn-left glyphicon glyphicon glyphicon-font"></span> Cheezeburger Shirt</li>
        <li class="ui-widget-content box_wrs_panel" api="wrs"   vvalue="Buckit Shirt"><span class="btn-left glyphicon glyphicon glyphicon-font"></span> Buckit Shirt</li>
        
           <li class="ui-widget-content box_wrs_panel" name="dantas" api="wrs"   vvalue="Lolcat Shirt1"><span class="btn-left glyphicon glyphicon glyphicon-font"></span>  Lolcat Shirt1</li>
        <li class="ui-widget-content box_wrs_panel" api="wrs"   vvalue="Cheezeburger Shirt1"><span class="btn-left glyphicon glyphicon glyphicon-font"></span> Cheezeburger Shirt1</li>
        <li class="ui-widget-content box_wrs_panel" api="wrs"   vvalue="Buckit Shirt1"><span class="btn-left glyphicon glyphicon glyphicon-font"></span> Buckit Shirt1</li>
        
      </ul>
    </div>
    
    <h2><a href="#">Bags</a> <button type="button" class="btn btn-link btn-xs navbar-right wrs_search_drad_drop_direita"><span class="glyphicon glyphicon-search "></span></button></h2>
    <div class="wrs_panel_options">
      <ul>
        <li class="ui-widget-content box_wrs_panel" api="wrs"   vvalue="Zebra Striped"><span class="btn-left glyphicon glyphicon glyphicon-font"></span> Zebra Striped</li>
        <li class="ui-widget-content box_wrs_panel" api="wrs"   vvalue="Black Leather"><span class="btn-left glyphicon glyphicon glyphicon-font"></span> Black Leather</li>
        <li class="ui-widget-content box_wrs_panel" api="wrs"   vvalue="Alligator Leather"><span class="btn-left glyphicon glyphicon glyphicon-font"></span> Alligator Leather</li>
        
        <li class="ui-widget-content box_wrs_panel" api="wrs"   vvalue="Zebra Striped1"><span class="btn-left glyphicon glyphicon glyphicon-font"></span> Zebra Striped1</li>
        <li class="ui-widget-content box_wrs_panel" api="wrs"   vvalue="Black Leather1"><span class="btn-left glyphicon glyphicon glyphicon-font"></span> Black Leather1</li>
        <li class="ui-widget-content box_wrs_panel" api="wrs"   vvalue="Alligator Leather1"><span class="btn-left glyphicon glyphicon glyphicon-font"></span> Alligator Leather1</li>
        
      </ul>
    </div>
    

    <h2><a href="#">Metricas</a> <button type="button" class="btn btn-link btn-xs navbar-right wrs_search_drad_drop_direita"><span class="glyphicon glyphicon-search "></span></button></h2>
    
    
    <div class="wrs_panel_options wrs_panel_options_metricas">
      <ul>
        <li class="ui-widget-content box_wrs_panel" api="wrs"   vvalue="iPhone"><span class="btn-left glyphicon glyphicon glyphicon-font"></span> iPhone</li>
        <li class="ui-widget-content box_wrs_panel" api="wrs"   vvalue="iPod"><span class="btn-left glyphicon glyphicon glyphicon-font"></span> iPod</li>
        <li class="ui-widget-content box_wrs_panel" api="wrs"   vvalue="iPad"><span class="btn-left glyphicon glyphicon glyphicon-font"></span> iPad</li>
        <li class="ui-widget-content box_wrs_panel" api="wrs"   vvalue="iPhone2"><span class="btn-left glyphicon glyphicon glyphicon-font"></span> iPhone2</li>
        <li class="ui-widget-content box_wrs_panel" api="wrs"   vvalue="iPod2"><span class="btn-left glyphicon glyphicon glyphicon-font"></span> iPod2</li>
        <li class="ui-widget-content box_wrs_panel" api="wrs"   vvalue="iPad2"><span class="btn-left glyphicon glyphicon glyphicon-font"></span> iPad2</li>
        
      </ul>
    </div>
  </div>
</div>














 

<div class="nav nav-tabs ui-accordion-header  ui-accordion-header-active ui-state-active wrs_panel_esquerdo_header DRAG_DROP_LATERAIS_title">
	<span class="navbar-left title_left">Metricas 1</span>
</div>

				
				


<div id="products" class="wrs_options_select  wrs_options_panel_metrica">
  <div class="WRS_DRAG_DROP WRS_DRAG_DROP_METRICA">
    <h2><a href="#">T-Shirts</a> <button type="button" class="btn btn-link btn-xs navbar-right wrs_search_drad_drop_direita"><span class="glyphicon glyphicon-search "></span></button></h2>    
    <div class="wrs_panel_options">
      <ul>
        <li class="ui-widget-content box_wrs_panel" type="metrica" api="wrs"   vvalue="Lolcat Shirt"><span class="btn-left glyphicon glyphicon-usd"></span> Lolcat Shirt</li>
        <li class="ui-widget-content box_wrs_panel" type="metrica" api="wrs"   vvalue="Cheezeburger Shirt"><span class="btn-left glyphicon glyphicon-usd"></span> Cheezeburger Shirt</li>
        <li class="ui-widget-content box_wrs_panel" type="metrica" api="wrs"   vvalue="Buckit Shirt"><span class="btn-left glyphicon glyphicon-usd"></span> Buckit Shirt</li>
      </ul>
    </div>
 
    

    <h2><a href="#">Metricas</a> <button type="button" class="btn btn-link btn-xs navbar-right wrs_search_drad_drop_direita"><span class="glyphicon glyphicon-search "></span></button></h2>
    <div class="wrs_panel_options">
      <ul>
        <li class="ui-widget-content box_wrs_panel" type="metrica" api="wrs"   vvalue="iPhone"><span class="btn-left glyphicon glyphicon-usd"></span> iPhone</li>
        <li class="ui-widget-content box_wrs_panel" type="metrica" api="wrs"   vvalue="iPod"><span class="btn-left glyphicon glyphicon-usd"></span> iPod</li>
        <li class="ui-widget-content box_wrs_panel" type="metrica" api="wrs"   vvalue="iPad"><span class="btn-left glyphicon glyphicon-usd"></span> iPad</li>
      </ul>
    </div>
  </div>
</div>


</div>
 
 
