<div class="DRAG_DROP_LATERAIS   wrs_container">


<div class="nav nav-tabs ui-accordion-header  ui-accordion-header-active ui-state-active wrs_panel_esquerdo_header">
	<span class="navbar-left title_left">Filtros</span>
	<div class="navbar-right btn-group DRAG_DROP_LATERAIS_title_btn_right" >
	
					  <button type="button" class="btn btn-warning btn-xs glyphicon glyphicon-trash wrs_clean_box_drag_drop"></button>
					  <button type="button"  class="btn btn-default btn-xs glyphicon glyphicon-filter wrs_panel_filter_icon"></button>
					  <button type="button" class="btn btn-default btn-xs glyphicon glyphicon-info-sign tooltip_info_wrs_panel"></button>
					  <button type="button" class="btn btn-default btn-xs glyphicon glyphicon-check wrs_run_filter"></button>
				</div>

</div>
 
	
 
	<div class="WRS_DRAG_DROP_RECEIVER WRS_DRAG_DROP_RECEIVER_FILTER  ">
	  <div class="ui-widget-content  wrs_panel_receive wrs_panel_esquerdo_drag_drop " type="filtro" who_receive="filtros">
	    <ol class="wrs_swap_drag_drop sortable_filtro  sortable_attr" LNG="DRAG_DROP_FIELD_ATRIBUTO"></ol>
	  </div>
	</div>

	<div class="WRS_DRAG_DROP_FILTER_CONTAINER">
	     <div class="WRS_DRAG_DROP_FILTER"></div>
	</div>
	
</div>





	 <script>
	 function makeFilterWRS()
	 {
		 $('.WRS_DRAG_DROP_RECEIVER_FILTER').hide();
	 	 $('.WRS_DRAG_DROP_FILTER_CONTAINER').show();
	 		
		 	var html		=	"";
		 	var h2			=	'<h2 vvalue="{vvalue}"><a href="#">{label}</a></h2><div>TESTE</div>';
			var h2_replace	=	 new Array('{vvalue}','{label}');
		 
			 $('.sortable_filtro li').each(function(){
				 	var value	=	$(this).attr('vvalue');

				 	if(!empty(value))
				 	{
					 	var replace		=	new Array(value,value);
					 		html		+=	str_replace(h2_replace,replace,h2);  		
				 	}
			 });

			//http://api.jqueryui.com/accordion/#method-destroy
			$( ".WRS_DRAG_DROP_FILTER" ).html(html);
			$( ".WRS_DRAG_DROP_FILTER" ).accordion( "option","active",false ).accordion( "refresh");
			 
	 }





	 
	 
	 $(document).ready(function() {
		 
		$('.WRS_DRAG_DROP_FILTER_CONTAINER').hide();
		$( ".WRS_DRAG_DROP_FILTER" ).accordion({collapsible: true,active: false});
		 

		$('.wrs_run_filter').click(function(){
										wrs_panel_layout.close('east');
										$('.wrs_panel_center_body').hide();
										$('.wrs_panel_filter_icon').hide();
										makeFilterWRS();
									});

		
		 $('.wrs_panel_filter_icon').click(function(){

				var filter_hide		=	$(this).attr('filter_hide');

				if(filter_hide!='true' && filter_hide!='false') filter_hide='false';

				if(filter_hide=='false'){	
			 		makeFilterWRS();
			 		filter_hide	=	true;
				}else{
					$('.WRS_DRAG_DROP_RECEIVER_FILTER').show();
					$('.WRS_DRAG_DROP_FILTER_CONTAINER').hide();
					filter_hide	=	 false;
				}

				$(this).attr('filter_hide', filter_hide);
		 });
	 });
	 
        $(document).ready(function() {
			var contentHTML	=	$('<div class="container"> <h3>[UNIDADE]</h3>  <p>40 - SPECIALITES</p><h3>[REGIONAL]</h3>  <p>40 - SPECIALITES</p><p>40 - SPECIALITES</p><p>40 - SPECIALITES</p><p>40 - SPECIALITES</p><p>40 - SPECIALITES</p><p>40 - SPECIALITES</p><p>40 - SPECIALITES</p><p>40 - SPECIALITES</p><p>40 - SPECIALITES</p><p>40 - SPECIALITES</p><p>40 - SPECIALITES</p><p>40 - SPECIALITES</p></div>');
        	   $('.tooltip_info_wrs_panel').qtip({
        	         content: {
								text: function(event, api) 
										{
											return contentHTML;
										},
								title : 'Filtros'
            	         },
        	         style: {
        	        	 classes: 'qtip-bootstrap qtip-shadow'
        	         }, events: {
        	             render: function(event, api) {
        	                 // Grab the BGIFrame element
        	                 var elem = api.elements.bgiframe;
        	             }}
        	         /*position: {
        	        	 my: 'top left',  // Position my top left...
        	             at: 'top right', // at the bottom right of...
        	             target: 'mouse', // Track the mouse as the positioning target
        	             adjust: { x: 20, y: 5 } // Offset it slightly from under the mouse
        	         }*/
        	     });
      	     
            
        });
    </script>
    
