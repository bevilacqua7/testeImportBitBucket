<table width="100%">
	<tr>
		<td width="33.33%"  valign="top" align="left"><img style="height: 55px;"  src="./imagens/logo-wrs.png" /> </td>
        <td width="33.33%"  valign="top" align="center">
        		<h3 class="ui-state-active no_border_background">DDD</h3>
        		<b>Edicao: </b> 201409 <br>
				<b>Atualizado:</b> 2015-03-03 20:19:04	
        </td>
        <td width="33.33%"  valign="top" align="right"><img style="height: 55px;" src="./imagens/logo-ims.png" /></td>
    </tr>
</table>