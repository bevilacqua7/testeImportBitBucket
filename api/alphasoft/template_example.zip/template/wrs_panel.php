<!DOCTYPE html>
<HTML xmlns="http://www.w3.org/1999/xhtml" xml:lang="pt-br" lang="pt-br"> 

<head>
<meta charset="utf-8" />
<meta http-equiv="content-type" content="text/html;charset=utf-8;" />

<script>
var wrs_panel_layout	=	'';
</script>
<title>Layout Example</title>

<!-- Fonte font-awesome-4.3.0 -->
 <link href="api/font-awesome-4.3.0/css/font-awesome.min.css?v=0.0.1" rel="stylesheet" type="text/css" />

  
<link rel="stylesheet" type="text/css" href="api/bootstrap-3.3.0/dist/css/bootstrap-wrs.css" />

<link rel="stylesheet" href="css/jquery/jquery-ui.css">

<link rel="stylesheet" type="text/css" href="css/theme-azul/jquery-ui-1.8.22.custom.css" />
<!-- <link rel="stylesheet" type="text/css" href="css/theme-verde/jquery-ui-1.8.22.custom.css" />  -->
<link rel="stylesheet" type="text/css" href="css/wrs_panel.css?<?php echo rand(0,99999);?>" />
<link rel="stylesheet" type="text/css" href="css/wrs_common.css?<?php echo rand(0,99999);?>" />


<script type="text/javascript" src="js/jquery-ui/jquery-latest.js"></script>
<script type="text/javascript" src="js/jquery/jquery-1.8.2.min.js"></script>

<!--  Conversões das funções do PHP para javascript -->
<script type="text/javascript" src="api/alphasoft/js/php_js.js"></script>

<script type="text/javascript" src="js/jquery-ui/jquery-ui.js"></script>

<!--  Ativa o Jquery para Mobile -->
<script type="text/javascript" src="js/jquery.ui.touch-punch.min.js"></script>

<!--  Complemento da API jqueryLayout -->
<script type="text/javascript" src="js/jquery-ui/jquery.layout-latest.js"></script>

<!--  Funções comuns do WRS -->
<script type="text/javascript" src="api/alphasoft/js/common.js"></script>

<!--  Configurações do idioma  -->
<script type="text/javascript" src="language_javascript.php"></script>

 <!--  Configurações do Contex Menu -->
  <script src="api/contextMenu/src/jquery.contextMenu.js" type="text/javascript"></script> 
  <link href="api/contextMenu/src/jquery.contextMenu.css?v=0.0.1" rel="stylesheet" type="text/css" />

 <!--  JS do BootStrap -->
  <script src="api/bootstrap-3.3.0/js/modal.js" type="text/javascript"></script> 
<!-- <script src="api/bootstrap-3.3.0/dist/js/bootstrap.min.js"></script> -->   
  
<!-- API MODAL ALERT-->
<link href="api/jquery.modal-1.2/css/jquery.modal.css" type="text/css" rel="stylesheet" />
<link href="api/jquery.modal-1.2/css/jquery.modal.theme-xenon.css" type="text/css" rel="stylesheet" />
<link href="api/jquery.modal-1.2/css/jquery.modal.theme-atlant.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="api/jquery.modal-1.2/js/jquery.modal.min.js"></script>
  
  
  
  
  	<!--[if lt IE 8]>
    	<link href="api/compatibilidade/bootstrap-ie7-master/css/bootstrap-ie7.css" rel="stylesheet">
	<![endif]-->


     <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  
  
<!-- Configurações do TOOLTIP -->  
<link href="api/jquery.qtip.custom/jquery.qtip.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="api/jquery.qtip.custom/jquery.qtip.min.js"></script>



	<!--[if lt IE 9]>
		<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>
<body>

<div class="ui-layout-center"><?php include 'wrs_panel_body.php';?></div>

<div class="ui-layout-north ui-state-focus"><?php include 'wrs_panel_header.php';?></div>
<div class="ui-layout-south ui-state-focus"><?php include 'wrs_menu_button.php';?></div>

<div class="ui-layout-east "><?php include 'wrs_panel_direito.php'; ?></div>
<div class="ui-layout-west "><?php include 'wrs_panel_esquerdo.php'; ?></div>



<script type="text/javascript" src="js/alphasoft/wrs_panel.js?<?php echo rand(0,9999999);?>"></script>

<?php 

	$result_box	= array();
	
	$result_box['LAYOUT_ROWS']			=	array('Lolcat Shirt','Cheezeburger Shirt');
	$result_box['LAYOUT_COLUMNS']		=	array('Zebra Striped','Black Leather');
	$result_box['LAYOUT_FILTERS']		=	array('Alligator Leather1',array('iPhone','simples'),array('iPhone2','simples'));
	$result_box['LAYOUT_MEASURES']		=	array('Cheezeburger Shirt',	'Buckit Shirt',	'iPad');
?>
 <script>
 set_value_box_relatorio(<?php echo json_encode($result_box,true);?>);
 </script>
 
 
 <!-- MODAL  -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content"></div>
  </div>
</div>



<script>

$('.wrs_open_modal').click(function(){
		$.post('testeModal.php',function(data){$('.modal-content').html(data)});
});



 </script>



</body>


</html>