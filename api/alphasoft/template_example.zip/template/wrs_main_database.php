<?php 

$description	=	 NULL;

if(!empty($CUBE_EDITION))
{

		$description	=	<<<EOF
								<p>
									<span><b class="color_wrs_label">Edicao : </b>{$CUBE_EDITION}</span>
								</p>
EOF;
	
}

if(!empty($CUBE_UPDATE))
{
	$description	.=	<<<EOF
								<p>
									<span><b class="color_wrs_label">Atualizado : </b>{$CUBE_UPDATE}</span>
								</p>
EOF;
}

if(!empty($WARNING)) $description=$WARNING;

$html	=<<<EOF
				<div class="ui-widget-content item wrs_audit-status wrs_item_santos" >
						<div class="meida-holder">
							<div class="background_item"></div>
							<h1>{$DATABASE_DESC}</h1>
							<description class="description">{$description}</description>
							<img src="imagens/databases/{$DATABASE_IMAGE}" alt="" />
						</div>
						<div class="hover-content">
							<div class="overlay"></div>
							<div class="link-contianer">
								<a href="{$LINK}" class="ui-widget-header changePage"><span
									class="glyphicon glyphicon-link"></span></a>
							</div>
							<div class="detail-container">
								<!-- <h4>Descrição</h4>-->
								<p>{$DATABASE_COMMENT}</p>
							</div>
						</div>
				</div>
EOF
				?>