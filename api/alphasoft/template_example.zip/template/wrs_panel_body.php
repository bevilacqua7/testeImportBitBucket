<div class="wrs_panel_filter_measure wrs_panel_center_body">


	<div class="container_center">
		<h4 class="ui-accordion-header  ui-accordion-header-active ui-state-active">Colunas
										<button type="button" class="btn btn-warning btn-xs glyphicon glyphicon-trash wrs_clean_box_drag_drop  wrs_clean_box_drag_drop_css" parent="no_parent"></button>
		</h4>
		<div class="WRS_DRAG_DROP_RECEIVER">
		  <div class="ui-widget-content  wrs_panel_receive wrs_panel_receive_coluna_linha ui-state-default" type="receive" who_receive="coluna">
		    <ol class="nav nav-tabs wrs_swap_drag_drop sortable_coluna sortable_attr" LNG="DRAG_DROP_FIELD_ATRIBUTO"></ol>
		  </div>
		</div>
	</div>
	
	<div class="container_center">
	<h4 class="ui-accordion-header  ui-accordion-header-active ui-state-active">Linhas <button type="button" class="btn btn-warning btn-xs glyphicon glyphicon-trash wrs_clean_box_drag_drop wrs_clean_box_drag_drop_css" parent="no_parent"></button></h4>
	<div class="WRS_DRAG_DROP_RECEIVER">
	  <div class="ui-widget-content  wrs_panel_receive wrs_panel_receive_coluna_linha ui-state-default" type="receive" who_receive="linha">
	    <ol class="nav nav-tabs wrs_swap_drag_drop sortable_attr sortable_linha" LNG="DRAG_DROP_FIELD_ATRIBUTO"></ol>
	  </div>
	</div>
	</div>
	
	<div class="container_center">
	<h4 class="ui-accordion-header  ui-accordion-header-active ui-state-active">Metricas <button type="button" class="btn btn-warning btn-xs glyphicon glyphicon-trash wrs_clean_box_drag_drop wrs_clean_box_drag_drop_css" parent="no_parent"></button></h4>
	<div class="WRS_DRAG_DROP_RECEIVER">
	  <div class="ui-widget-content  wrs_panel_receive ui-state-default" type="metrica" who_receive="metrica">
	    <ol class="nav nav-tabs wrs_swap_drag_drop sortable_metrica" LNG="DRAG_DROP_FIELD_METRICA"></ol>
	  </div>
	</div>
	</div>

</div>
 
 
 
 <div class="WRS_ABA">
 			<ul class="nav nav-tabs">
				  <li role="presentation" class="active"><a   href="#">Aba 1<span class="icon-remove-aba glyphicon glyphicon-remove"></span></a></li>
				  <li role="presentation"><a href="#" >Aba 2<span class="icon-remove-aba glyphicon glyphicon-remove"></span> </a></li>
				  <li role="presentation"><a href="#">Aba 3<span class="icon-remove-aba glyphicon glyphicon-remove"></span></a></li>
				  <li role="presentation"><a href="#">Aba 4<span class="icon-remove-aba glyphicon glyphicon-remove"></span></a></li>
				  <li role="presentation"><a href="#">Aba 5<span class="icon-remove-aba glyphicon glyphicon-remove"></span></a></li>
				  <li role="presentation"><a href="#">Aba 6<span class="icon-remove-aba glyphicon glyphicon-remove"></span></a></li>
				  <li role="presentation"><a href="#">Aba 7<span class="icon-remove-aba glyphicon glyphicon-remove"></span></a></li>
				  <li role="presentation"><a href="#">Aba 8<span class="icon-remove-aba glyphicon glyphicon-remove"></span></a></li>
				  <li role="presentation"><a href="#">Aba 9<span class="icon-remove-aba glyphicon glyphicon-remove"></span></a></li>
				  <li role="presentation"><a href="#">Aba 10<span class="icon-remove-aba glyphicon glyphicon-remove"></span></a></li>
				  <li role="presentation"><a href="#">Aba 11<span class="icon-remove-aba glyphicon glyphicon-remove"></span></a></li>
				  <li role="presentation"><a href="#">Aba 12<span class="icon-remove-aba glyphicon glyphicon-remove"></span></a></li>
			</ul>
 </div>


<!--  Styles css ui-state-default -->